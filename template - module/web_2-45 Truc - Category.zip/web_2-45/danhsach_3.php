<!DOCTYPE html>

<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <?php
        if (!class_exists('lessc')) {
            include ('./libs/lessc.inc.php');
        }
        $less = new lessc;
        $less->compileFile('less/styles.less', 'css/styles.css');
        ?>
        <?php
        if (!class_exists('lessc')) {
            include ('./libs/lessc.inc.php');
        }
        $less = new lessc;
        $less->compileFile('less/danhsach_3.less', 'css/danhsach_3.css');
        ?>
        <link href="css/styles.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery-2.2.4.min.js" type="text/javascript"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <script src="js/newjavascript.js" type="text/javascript"></script>
    </head>
    <body>
        <div class="type-45-1">
            <div class="fullwidth-section dt-sc-parallax-section" style="background-image: url(images/bg-rooms.jpg) !important; background-size: cover!important; background-position: center; background-repeat: no-repeat!important; padding: 50px;">
                <div class="banner">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="background" style="background-color:rgb(235, 235, 235); width: 100%;
                                     padding: 50px;
                                     margin-left: 1px;
                                     margin-top: 48px;
                                     ">
                                    <div class="word">
                                        <p>STARTING AT $120 / NIGHT</p>
                                    </div>
                                    <div class="word2">    
                                        <h1>ROUND COVE SUITE</h1>
                                    </div>
                                    <p>Quae vero auctorem tractata ab fiducia dicuntur. Morbi fringilla convallis
                                        <br>sapien, id pulvinar odio volutpat</p>

                                    <div class="event">
                                        <br><i class="fa fa-caret-right" aria-hidden="true"></i>Cum ceteris in veneratione tui montes
                                        <br><i class="fa fa-caret-right" aria-hidden="true"></i>Fabio vel iudice vincam, sunt in culpa qui officia
                                        <br><i class="fa fa-caret-right" aria-hidden="true"></i>Gallia est omnis divisa
                                        <br><i class="fa fa-caret-right" aria-hidden="true"></i>Ut enim ad minim veniam, quis nostrud exercitation
                                        <br><i class="fa fa-caret-right" aria-hidden="true"></i>Fabio vel iudice vincam sunt
                                    </div>
                                    <p>
                                        <a class="btn btn-inline" style="color: #000; "href="#">Book The Round Cove Suite Now</a>
                                    </p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="images">
                                    <img src="images/content-room-768x576.jpg" style="position: relative;                                       
                                         width: 100%;
                                         padding-top:40px;
                                         }">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>                                           
