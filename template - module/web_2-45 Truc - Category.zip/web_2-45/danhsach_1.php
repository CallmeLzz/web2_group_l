<!DOCTYPE html>

<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <?php
        if (!class_exists('lessc')) {
            include ('./libs/lessc.inc.php');
        }
        $less = new lessc;
        $less->compileFile('less/styles.less', 'css/styles.css');
        ?>
        <?php
        if (!class_exists('lessc')) {
            include ('./libs/lessc.inc.php');
        }
        $less = new lessc;
        $less->compileFile('less/danhsach_1.less', 'css/danhsach_1.css');
        ?>
        <link href="css/styles.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery-2.2.4.min.js" type="text/javascript"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <script src="js/newjavascript.js" type="text/javascript"></script>
    </head>
    <body>
        <div class="type-45">
            <div id="page-heading">
                <div style="background: url(images/bg-header-6.jpg);background-size: cover;
                     background-position: center top;
                     width:100%; padding:100px; ">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="text">
                                <h1 style="font-weight: 400;
                                    /* margin: 15px; */
                                    margin-top: 105px;
                                    padding: 0px;
                                    color: white;
                                    ">Rooms Listing</h1>
                                <p style="color: rgba(97, 104, 115, 0.63);
                                   font-size: 20px;
                                   margin-top: -2px;
                                   ">Starting at $120</p>
                            </div>
                        </div>
                    </div>
                </div> 
            </div>
        </div>
    </div>
</body>
</html>                                           
