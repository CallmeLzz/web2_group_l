<!DOCTYPE html>

<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <?php
        if (!class_exists('lessc')) {
            include ('./libs/lessc.inc.php');
        }
        $less = new lessc;
        $less->compileFile('less/styles.less', 'css/styles.css');
        ?>
        <?php
        if (!class_exists('lessc')) {
            include ('./libs/lessc.inc.php');
        }
        $less = new lessc;
        $less->compileFile('less/danhsach_2.less', 'css/danhsach_2.css');
        ?>
        <link href="css/styles.css" rel="stylesheet" type="text/css"/>
        <script src="js/jquery-2.2.4.min.js" type="text/javascript"></script>
        <script src="js/bootstrap.min.js" type="text/javascript"></script>
        <script src="js/newjavascript.js" type="text/javascript"></script>
    </head>
    <body>
        <div class="type_45">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="word3">
                            <p style="margin-top:30px;">Unam incolunt Belgae, aliam Aquitani, tertiam. Idque Caesaris facere 
                                <br>voluntate liceret: sese habere. Quis aute iure reprehenderit in voluptate 
                                <br>velit esse. Ab illo tempore, ab est sed immemorabili. Quam temere in 
                                <br>vitiis legem.</p>
                            <h3>Curabitur blandit tempus ardua</h3>
                            <p>Salutantibus vitae elit libero, a pharetra augue. At nos hinc posthac, sitientis piros Afros. Quisque ut dolor gravida, placerat libero vel, euismod. Ut enim ad minim veniam, quis nostrud exercitation. Unam incolunt Belgae, aliam Aquitani, tertiam. Unam incolunt Belgae, aliam Aquitani, tertiam. Tityre, tu patulae recubans sub tegmine fagi dolor. Curabitur est gravida.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="container">
                            <div class="images">
                                <img src="images/content-rooms-4.jpg" style="width: 50%;" >
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>                                           
